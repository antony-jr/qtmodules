function Component() {

}

Component.prototype.isDefault = function()
{
    return true;
}
